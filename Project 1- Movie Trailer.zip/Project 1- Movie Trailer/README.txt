Getting Started

media.py
This code provides a way to store movie related information by creating a movie title, storyline, poster image, and youtube trailer for a movie.

entertainment.py
This code uses media.py to create movie information for three movies: Rambo, Finding Nemo, and Finding Dory.  It then uses the fresh_tomatoes script provided to turn the movie information into an interactive weppage.

fresh_tomatoes.py
Provided by the course.